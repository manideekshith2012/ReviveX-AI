import { Link, useLocation } from "wouter";
import {
  Activity, LayoutDashboard, MessageSquare, Crosshair,
  Target, Settings, LogOut, X,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Orb } from "@/components/ui/orb";

interface AppSidebarProps {
  onClose?: () => void;
}

export function AppSidebar({ onClose }: AppSidebarProps) {
  const [location] = useLocation();

  const navItems = [
    { icon: LayoutDashboard, label: "Dashboard", href: "/dashboard" },
    { icon: MessageSquare, label: "AI Chat", href: "/chat" },
    { icon: Crosshair, label: "Diagnosis", href: "/diagnosis" },
    { icon: Target, label: "SWOT Analysis", href: "/swot" },
    { icon: Activity, label: "Action Plan", href: "/action-plan" },
    { icon: Settings, label: "Settings", href: "/settings" },
  ];

  return (
    <div className="w-64 h-screen border-r border-border/50 bg-card/60 backdrop-blur-xl flex flex-col p-4 fixed left-0 top-0 z-40">
      {/* Header */}
      <div className="flex items-center gap-3 px-2 py-3 mb-5 border-b border-border/50">
        <Activity className="w-5 h-5 text-primary shrink-0" />
        <span className="font-bold text-base tracking-tight">ReviveX AI</span>
        {/* Close button for mobile */}
        {onClose && (
          <button
            data-testid="button-close-sidebar"
            onClick={onClose}
            className="ml-auto p-1.5 rounded-lg text-muted-foreground hover:text-foreground hover:bg-white/10 transition-colors"
            aria-label="Close menu"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Nav items */}
      <nav className="flex-1 space-y-1">
        {navItems.map((item) => {
          const isActive = location === item.href;
          return (
            <Link key={item.href} href={item.href} onClick={onClose}>
              <div
                data-testid={`nav-${item.href.replace("/", "")}`}
                className={cn(
                  "flex items-center gap-3 px-3 py-3 rounded-xl transition-all cursor-pointer min-h-[48px]",
                  isActive
                    ? "bg-primary/10 text-primary border border-primary/20 glow-blue"
                    : "text-muted-foreground hover:bg-white/5 hover:text-foreground"
                )}
              >
                <item.icon className="w-5 h-5 shrink-0" />
                <span className="font-medium text-sm">{item.label}</span>
              </div>
            </Link>
          );
        })}
      </nav>

      {/* Footer */}
      <div className="mt-auto pt-4 border-t border-border/50">
        <Link href="/" onClick={onClose}>
          <div className="flex items-center gap-3 px-3 py-3 rounded-xl text-muted-foreground hover:bg-white/5 hover:text-foreground cursor-pointer transition-colors min-h-[48px]">
            <LogOut className="w-5 h-5 shrink-0" />
            <span className="font-medium text-sm">Home</span>
          </div>
        </Link>
      </div>

      {/* Floating AI orb — only on desktop to avoid overlap on mobile */}
      <Link href="/chat">
        <div className="fixed bottom-6 right-6 z-50 cursor-pointer group hidden md:block">
          <div className="absolute inset-0 bg-primary/20 rounded-full blur-xl group-hover:bg-primary/40 transition-all" />
          <Orb className="w-14 h-14" pulsing />
        </div>
      </Link>
    </div>
  );
}
