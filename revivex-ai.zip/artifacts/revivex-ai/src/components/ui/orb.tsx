import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

interface OrbProps {
  className?: string;
  pulsing?: boolean;
  thinking?: boolean;
  crisisMode?: boolean;
}

export function Orb({ className, pulsing = true, thinking = false, crisisMode = false }: OrbProps) {
  return (
    <motion.div
      className={cn(
        "relative rounded-full blur-sm",
        crisisMode ? "bg-red-500" : "bg-primary",
        className
      )}
      animate={{
        scale: thinking ? [1, 1.2, 1] : pulsing ? [1, 1.05, 1] : 1,
        opacity: thinking ? [0.6, 1, 0.6] : [0.8, 1, 0.8],
      }}
      transition={{
        duration: thinking ? 1 : 3,
        repeat: Infinity,
        ease: "easeInOut",
      }}
    >
      <div className={cn(
        "absolute inset-0 rounded-full mix-blend-screen",
        crisisMode ? "glow-red" : "glow-blue"
      )} />
      {thinking && (
        <motion.div
          className="absolute inset-0 rounded-full border-2 border-white/30"
          animate={{ scale: [1, 1.5], opacity: [1, 0] }}
          transition={{ duration: 1.5, repeat: Infinity }}
        />
      )}
    </motion.div>
  );
}
