import { AppLayout } from "@/components/layout/AppLayout";
import { useTheme } from "@/lib/theme";
import { Card, CardContent } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Check } from "lucide-react";
import { cn } from "@/lib/utils";

const THEMES = [
  { id: "cyber", name: "Neon Cyber", bg: "bg-[#0b0f19]", accent: "bg-[#00d2ff]" },
  { id: "executive", name: "Executive Gold", bg: "bg-[#1a1a1a]", accent: "bg-[#ffb700]" },
  { id: "amoled", name: "AMOLED Focus", bg: "bg-[#000000]", accent: "bg-[#9d4edd]" },
  { id: "emerald", name: "Emerald Growth", bg: "bg-[#051a10]", accent: "bg-[#00e676]" },
  { id: "sunset", name: "Sunset Motivation", bg: "bg-[#1a0f14]", accent: "bg-[#ff5100]" }
] as const;

export default function Settings() {
  const { theme, setTheme } = useTheme();

  return (
    <AppLayout>
      <div className="max-w-4xl mx-auto space-y-8">
        <header>
          <h1 className="text-3xl font-bold tracking-tight">System Configuration</h1>
          <p className="text-muted-foreground mt-1">Customize your command center environment.</p>
        </header>

        <div className="space-y-6">
          <div>
            <h2 className="text-xl font-semibold mb-4">Interface Theme</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              {THEMES.map((t) => (
                <Card 
                  key={t.id} 
                  className={cn(
                    "cursor-pointer overflow-hidden transition-all hover:scale-105 border-2",
                    theme === t.id ? "border-primary shadow-[0_0_15px_rgba(0,0,0,0.5)] shadow-primary/20" : "border-border/50 opacity-70 hover:opacity-100"
                  )}
                  onClick={() => setTheme(t.id as any)}
                >
                  <CardContent className="p-0">
                    <div className={cn("h-24 w-full relative", t.bg)}>
                      <div className={cn("absolute bottom-4 right-4 w-6 h-6 rounded-full", t.accent)} />
                      {theme === t.id && (
                        <div className="absolute top-4 right-4 bg-white/10 p-1 rounded-full backdrop-blur">
                          <Check className="w-4 h-4 text-white" />
                        </div>
                      )}
                    </div>
                    <div className="p-4 bg-card">
                      <p className="font-medium text-sm">{t.name}</p>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          <div className="border-t border-border/50 pt-8 space-y-6">
            <h2 className="text-xl font-semibold">Preferences</h2>
            
            <div className="flex items-center justify-between p-4 bg-card/50 rounded-xl border border-border/50">
              <div className="space-y-0.5">
                <Label className="text-base">Crisis Mode UI</Label>
                <p className="text-sm text-muted-foreground">Enables aggressive red styling when health score drops below 40.</p>
              </div>
              <Switch defaultChecked />
            </div>

            <div className="flex items-center justify-between p-4 bg-card/50 rounded-xl border border-border/50">
              <div className="space-y-0.5">
                <Label className="text-base">Voice Input Ready</Label>
                <p className="text-sm text-muted-foreground">Allow microphone access for hands-free AI interaction.</p>
              </div>
              <Switch defaultChecked />
            </div>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
