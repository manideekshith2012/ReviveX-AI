import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Activity } from "lucide-react";
import { Orb } from "@/components/ui/orb";

export default function Login() {
  const [, setLocation] = useLocation();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLocation("/dashboard");
  };

  return (
    <div className="min-h-screen flex items-center justify-center relative overflow-hidden bg-background">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-primary/10 via-background to-background"></div>
      
      <div className="w-full max-w-md p-8 relative z-10">
        <div className="text-center mb-10">
          <Orb className="w-16 h-16 mx-auto mb-6" pulsing />
          <h1 className="text-3xl font-bold tracking-tight text-foreground">Welcome Back, Commander</h1>
          <p className="text-muted-foreground mt-2">Initialize recovery sequence.</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6 bg-card/50 p-8 rounded-2xl border border-border/50 backdrop-blur-xl">
          <div className="space-y-2">
            <Label htmlFor="email" className="text-muted-foreground">Command Email</Label>
            <Input id="email" type="email" placeholder="ceo@company.com" className="bg-background/50 border-border/50 focus:border-primary" required />
          </div>
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <Label htmlFor="password" className="text-muted-foreground">Access Code</Label>
              <span className="text-xs text-primary hover:underline cursor-pointer">Lost code?</span>
            </div>
            <Input id="password" type="password" className="bg-background/50 border-border/50 focus:border-primary" required />
          </div>
          
          <Button type="submit" className="w-full h-12 bg-primary/20 text-primary border border-primary/50 hover:bg-primary/30 glow-blue">
            Authenticate
          </Button>

          <div className="text-center text-sm text-muted-foreground">
            New protocol? <Link href="/register" className="text-primary hover:underline">Initialize here</Link>
          </div>
        </form>
      </div>
    </div>
  );
}
