import { motion } from "framer-motion";
import { Navbar } from "@/components/layout/Navbar";
import { Button } from "@/components/ui/button";
import { ArrowRight, BarChart2, ShieldAlert, Zap, Globe, MessageSquare } from "lucide-react";
import { Link } from "wouter";
import { Orb } from "@/components/ui/orb";

export default function Home() {
  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden">
      <Navbar />
      
      {/* Hero Section */}
      <section className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 overflow-hidden">
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#4f4f4f2e_1px,transparent_1px),linear-gradient(to_bottom,#4f4f4f2e_1px,transparent_1px)] bg-[size:14px_24px] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)]"></div>
        <div className="container mx-auto px-4 relative z-10">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center max-w-4xl mx-auto"
          >
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 border border-primary/20 text-primary mb-8">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
              </span>
              <span className="text-sm font-medium tracking-wide">SYSTEM ONLINE</span>
            </div>
            <h1 className="text-5xl md:text-7xl font-bold tracking-tighter mb-6 bg-clip-text text-transparent bg-gradient-to-r from-white via-primary/50 to-white pb-2">
              Don't Lose Your Business.<br />Let AI Save It.
            </h1>
            <p className="text-xl text-muted-foreground mb-10 max-w-2xl mx-auto leading-relaxed">
              ReviveX AI is your elite, 24/7 business recovery command center. We diagnose the bleed, build the action plan, and guide you out of the crisis.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link href="/register">
                <Button size="lg" className="w-full sm:w-auto h-14 px-8 text-lg bg-primary text-primary-foreground hover:bg-primary/90 glow-blue">
                  Start Recovery Protocol <ArrowRight className="ml-2 w-5 h-5" />
                </Button>
              </Link>
              <Link href="/login">
                <Button size="lg" variant="outline" className="w-full sm:w-auto h-14 px-8 text-lg border-primary/30 hover:bg-primary/10">
                  Access Dashboard
                </Button>
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Features */}
      <section className="py-24 bg-card/30 border-y border-border/50 backdrop-blur-sm">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { icon: ShieldAlert, title: "Crisis Diagnosis", desc: "Instant AI analysis of your failing metrics to pinpoint exactly where you're bleeding cash." },
              { icon: Zap, title: "Action Plans", desc: "Step-by-step, day-by-day recovery protocols tailored to your specific industry." },
              { icon: BarChart2, title: "Health Monitoring", desc: "Live dashboard tracking your recovery streak and vital signs." }
            ].map((f, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.2 }}
                className="p-8 rounded-2xl bg-background border border-border/50 hover:border-primary/50 transition-colors"
              >
                <f.icon className="w-10 h-10 text-primary mb-4" />
                <h3 className="text-xl font-bold mb-2">{f.title}</h3>
                <p className="text-muted-foreground">{f.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Demo Section */}
      <section className="py-32 relative">
        <div className="container mx-auto px-4 text-center">
          <Orb className="w-32 h-32 mx-auto mb-12" pulsing />
          <h2 className="text-3xl md:text-5xl font-bold mb-6">Your Personal War Room</h2>
          <p className="text-xl text-muted-foreground mb-12 max-w-2xl mx-auto">
            Stop guessing. Start executing. ReviveX acts as your CFO, CMO, and COO combined into one ruthless, empathetic intelligence.
          </p>
        </div>
      </section>
    </div>
  );
}
