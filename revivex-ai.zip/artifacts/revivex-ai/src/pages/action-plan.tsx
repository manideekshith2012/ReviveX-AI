import { AppLayout } from "@/components/layout/AppLayout";
import { useState } from "react";
import { useGenerateActionPlan } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { CheckCircle2, Circle } from "lucide-react";

export default function ActionPlanPage() {
  const [industry, setIndustry] = useState("");
  const [goal, setGoal] = useState("");
  
  const generatePlan = useGenerateActionPlan();

  const handleGenerate = (e: React.FormEvent) => {
    e.preventDefault();
    generatePlan.mutate({ data: { industry, goals: [goal], timeframe: "4 weeks" } });
  };

  return (
    <AppLayout>
      <div className="max-w-4xl mx-auto space-y-8">
        <header>
          <h1 className="text-3xl font-bold tracking-tight">Tactical Action Plan</h1>
          <p className="text-muted-foreground mt-1">Generate a week-by-week recovery protocol.</p>
        </header>

        <Card className="bg-card/50 border-border/50 backdrop-blur">
          <CardContent className="p-6">
            <form onSubmit={handleGenerate} className="flex gap-4 items-end">
              <div className="flex-1 space-y-2">
                <label className="text-sm font-medium">Industry</label>
                <Input value={industry} onChange={e => setIndustry(e.target.value)} required className="bg-background/50" />
              </div>
              <div className="flex-[2] space-y-2">
                <label className="text-sm font-medium">Primary Goal</label>
                <Input value={goal} onChange={e => setGoal(e.target.value)} placeholder="e.g. Stop user churn" required className="bg-background/50" />
              </div>
              <Button type="submit" disabled={generatePlan.isPending} className="h-10">
                {generatePlan.isPending ? "Generating..." : "Draft Protocol"}
              </Button>
            </form>
          </CardContent>
        </Card>

        {generatePlan.data && (
          <div className="space-y-8 mt-8 relative">
            <div className="absolute left-[27px] top-4 bottom-4 w-px bg-border/50" />
            
            <h2 className="text-2xl font-bold">{generatePlan.data.title}</h2>
            
            {generatePlan.data.steps.map((step, i) => (
              <div key={i} className="flex gap-6 relative z-10">
                <div className="w-14 h-14 rounded-full bg-card border-2 border-primary flex items-center justify-center font-bold text-primary shrink-0 shadow-[0_0_15px_rgba(0,0,0,0.5)] shadow-primary/20">
                  W{step.week}
                </div>
                <Card className="flex-1 bg-card/50 backdrop-blur border-border/50 hover:border-primary/30 transition-colors">
                  <CardContent className="p-5">
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="font-bold text-lg">{step.action}</h3>
                      <span className={`text-xs px-2 py-1 rounded-full ${step.priority === 'High' ? 'bg-destructive/20 text-destructive' : 'bg-primary/20 text-primary'}`}>
                        {step.priority} Priority
                      </span>
                    </div>
                    <p className="text-muted-foreground text-sm">{step.details}</p>
                  </CardContent>
                </Card>
              </div>
            ))}
          </div>
        )}
      </div>
    </AppLayout>
  );
}
