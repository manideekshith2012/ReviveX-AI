import { AppLayout } from "@/components/layout/AppLayout";
import { useState } from "react";
import { useRunBusinessDiagnosis } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ShieldAlert, CheckCircle2, ChevronRight, Activity } from "lucide-react";
import { motion } from "framer-motion";
import { Progress } from "@/components/ui/progress";

const INDUSTRIES = ["SaaS", "E-commerce", "Restaurant", "Agency", "Retail", "Creator"];
const PROBLEMS = ["Low Sales", "High Churn", "Cash Flow", "Bad Marketing", "Operations"];

export default function Diagnosis() {
  const [step, setStep] = useState(1);
  const [industry, setIndustry] = useState("");
  const [problems, setProblems] = useState<string[]>([]);
  
  const runDiagnosis = useRunBusinessDiagnosis();

  const handleAnalyze = () => {
    runDiagnosis.mutate({
      data: { industry, problemAreas: problems }
    }, {
      onSuccess: () => setStep(4)
    });
    setStep(3); // scanning state
  };

  return (
    <AppLayout>
      <div className="max-w-4xl mx-auto space-y-8">
        <header className="text-center mb-12">
          <div className="inline-flex items-center justify-center p-3 bg-primary/10 rounded-full mb-4">
            <ShieldAlert className="w-8 h-8 text-primary" />
          </div>
          <h1 className="text-4xl font-bold tracking-tight mb-2">Deep Diagnosis</h1>
          <p className="text-muted-foreground text-lg">Identify the source of the bleed.</p>
        </header>

        {step === 1 && (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-6">
            <h2 className="text-xl font-semibold">Select your industry</h2>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {INDUSTRIES.map(ind => (
                <Card 
                  key={ind} 
                  className={`cursor-pointer transition-all hover:border-primary/50 ${industry === ind ? 'border-primary bg-primary/5' : 'bg-card/50'}`}
                  onClick={() => setIndustry(ind)}
                >
                  <CardContent className="p-6 text-center font-medium">
                    {ind}
                  </CardContent>
                </Card>
              ))}
            </div>
            <div className="flex justify-end">
              <Button disabled={!industry} onClick={() => setStep(2)} className="h-12 px-8">Next <ChevronRight className="ml-2 w-4 h-4" /></Button>
            </div>
          </motion.div>
        )}

        {step === 2 && (
          <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="space-y-6">
            <h2 className="text-xl font-semibold">What are the primary symptoms?</h2>
            <div className="flex flex-wrap gap-3">
              {PROBLEMS.map(prob => {
                const isSelected = problems.includes(prob);
                return (
                  <Button
                    key={prob}
                    variant={isSelected ? "default" : "outline"}
                    className={`rounded-full h-10 ${isSelected ? 'bg-primary text-primary-foreground' : 'bg-card/50'}`}
                    onClick={() => {
                      if (isSelected) setProblems(problems.filter(p => p !== prob));
                      else setProblems([...problems, prob]);
                    }}
                  >
                    {prob}
                  </Button>
                );
              })}
            </div>
            <div className="flex justify-between">
              <Button variant="ghost" onClick={() => setStep(1)}>Back</Button>
              <Button disabled={problems.length === 0} onClick={handleAnalyze} className="h-12 px-8 bg-destructive hover:bg-destructive/90 text-white">Initialize Scan <Activity className="ml-2 w-4 h-4" /></Button>
            </div>
          </motion.div>
        )}

        {step === 3 && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="py-20 text-center space-y-8">
            <div className="relative w-32 h-32 mx-auto">
              <div className="absolute inset-0 border-4 border-primary/20 rounded-full" />
              <div className="absolute inset-0 border-4 border-primary rounded-full border-t-transparent animate-spin" />
              <Activity className="absolute inset-0 m-auto w-10 h-10 text-primary animate-pulse" />
            </div>
            <div>
              <h3 className="text-2xl font-bold mb-2">Analyzing System Data</h3>
              <p className="text-muted-foreground">Running diagnostics across {industry} benchmarks...</p>
            </div>
          </motion.div>
        )}

        {step === 4 && runDiagnosis.data && (
          <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="space-y-6">
            <Card className="bg-destructive/10 border-destructive/20">
              <CardContent className="p-8">
                <div className="flex items-center gap-4 mb-6">
                  <div className="w-16 h-16 rounded-full bg-destructive/20 flex items-center justify-center text-2xl font-bold text-destructive">
                    {runDiagnosis.data.urgencyScore}
                  </div>
                  <div>
                    <h2 className="text-2xl font-bold text-destructive">Critical Urgency</h2>
                    <p className="text-muted-foreground">Estimated recovery window: {runDiagnosis.data.recoveryTimeEstimate}</p>
                  </div>
                </div>
                <p className="text-lg leading-relaxed">{runDiagnosis.data.summary}</p>
              </CardContent>
            </Card>

            <div className="grid md:grid-cols-2 gap-6">
              <Card className="bg-card/50">
                <CardContent className="p-6 space-y-4">
                  <h3 className="font-bold flex items-center gap-2"><ShieldAlert className="w-5 h-5 text-orange-500" /> Core Issues</h3>
                  <ul className="space-y-3">
                    {runDiagnosis.data.issues.map((issue, i) => (
                      <li key={i} className="flex items-start gap-2 text-sm">
                        <div className="mt-1 w-1.5 h-1.5 rounded-full bg-orange-500 shrink-0" />
                        <span className="text-muted-foreground">{issue}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>

              <Card className="bg-card/50">
                <CardContent className="p-6 space-y-4">
                  <h3 className="font-bold flex items-center gap-2"><CheckCircle2 className="w-5 h-5 text-primary" /> Immediate Actions</h3>
                  <ul className="space-y-3">
                    {runDiagnosis.data.recommendations.map((rec, i) => (
                      <li key={i} className="flex items-start gap-2 text-sm">
                        <div className="mt-1 w-1.5 h-1.5 rounded-full bg-primary shrink-0" />
                        <span className="text-muted-foreground">{rec}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            </div>
            <div className="text-center mt-8">
              <Button onClick={() => setStep(1)} variant="outline">Run New Scan</Button>
            </div>
          </motion.div>
        )}
      </div>
    </AppLayout>
  );
}
