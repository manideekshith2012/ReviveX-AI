import { AppLayout } from "@/components/layout/AppLayout";
import { useState } from "react";
import { useGenerateSwot } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Target, TrendingUp, AlertTriangle, ShieldAlert } from "lucide-react";

export default function Swot() {
  const [industry, setIndustry] = useState("");
  const [desc, setDesc] = useState("");
  
  const generateSwot = useGenerateSwot();

  const handleGenerate = (e: React.FormEvent) => {
    e.preventDefault();
    generateSwot.mutate({ data: { industry, businessDescription: desc } });
  };

  return (
    <AppLayout>
      <div className="max-w-6xl mx-auto space-y-8">
        <header>
          <h1 className="text-3xl font-bold tracking-tight">SWOT Intelligence</h1>
          <p className="text-muted-foreground mt-1">AI-generated strategic analysis.</p>
        </header>

        <Card className="bg-card/50 border-border/50 backdrop-blur">
          <CardContent className="p-6">
            <form onSubmit={handleGenerate} className="flex gap-4 items-end">
              <div className="flex-1 space-y-2">
                <label className="text-sm font-medium">Industry</label>
                <Input value={industry} onChange={e => setIndustry(e.target.value)} placeholder="e.g. SaaS" required className="bg-background/50" />
              </div>
              <div className="flex-[2] space-y-2">
                <label className="text-sm font-medium">Business Context</label>
                <Input value={desc} onChange={e => setDesc(e.target.value)} placeholder="Briefly describe what you do..." required className="bg-background/50" />
              </div>
              <Button type="submit" disabled={generateSwot.isPending} className="h-10 bg-primary text-primary-foreground">
                {generateSwot.isPending ? "Analyzing..." : "Generate Matrix"}
              </Button>
            </form>
          </CardContent>
        </Card>

        {generateSwot.data && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8">
            <Card className="bg-green-500/5 border-green-500/20">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-green-500">
                  <Target className="w-5 h-5" /> Strengths
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {generateSwot.data.strengths.map((item, i) => (
                    <li key={i} className="flex gap-2 text-sm"><div className="w-1.5 h-1.5 mt-1.5 rounded-full bg-green-500 shrink-0"/>{item}</li>
                  ))}
                </ul>
              </CardContent>
            </Card>

            <Card className="bg-red-500/5 border-red-500/20">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-red-500">
                  <AlertTriangle className="w-5 h-5" /> Weaknesses
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {generateSwot.data.weaknesses.map((item, i) => (
                    <li key={i} className="flex gap-2 text-sm"><div className="w-1.5 h-1.5 mt-1.5 rounded-full bg-red-500 shrink-0"/>{item}</li>
                  ))}
                </ul>
              </CardContent>
            </Card>

            <Card className="bg-primary/5 border-primary/20">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-primary">
                  <TrendingUp className="w-5 h-5" /> Opportunities
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {generateSwot.data.opportunities.map((item, i) => (
                    <li key={i} className="flex gap-2 text-sm"><div className="w-1.5 h-1.5 mt-1.5 rounded-full bg-primary shrink-0"/>{item}</li>
                  ))}
                </ul>
              </CardContent>
            </Card>

            <Card className="bg-orange-500/5 border-orange-500/20">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-orange-500">
                  <ShieldAlert className="w-5 h-5" /> Threats
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {generateSwot.data.threats.map((item, i) => (
                    <li key={i} className="flex gap-2 text-sm"><div className="w-1.5 h-1.5 mt-1.5 rounded-full bg-orange-500 shrink-0"/>{item}</li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </AppLayout>
  );
}
