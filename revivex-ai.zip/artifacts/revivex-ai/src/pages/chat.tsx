import { AppLayout } from "@/components/layout/AppLayout";
import { Button } from "@/components/ui/button";
import {
  useListChatSessions,
  useGetChatSession,
  useSendMessage,
  useCreateChatSession,
  useDeleteChatSession,
  getListChatSessionsQueryKey,
  getGetChatSessionQueryKey,
} from "@workspace/api-client-react";
import { Orb } from "@/components/ui/orb";
import {
  MessageSquare, Plus, Send, AlertTriangle, Trash2,
  Zap, TrendingUp, Users, DollarSign, BarChart2, Target,
  Flame, ShieldAlert, Mic, MicOff, Volume2, VolumeX, Globe,
  ChevronDown, PanelLeftOpen, PanelLeftClose,
} from "lucide-react";
import { useState, useRef, useEffect, useCallback } from "react";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";
import { motion, AnimatePresence } from "framer-motion";
import { useQueryClient } from "@tanstack/react-query";

// ─── Language config ──────────────────────────────────────────────────────────
const LANGUAGES = [
  { code: "en", label: "English",    flag: "🇺🇸" },
  { code: "es", label: "Español",    flag: "🇪🇸" },
  { code: "hi", label: "हिन्दी",      flag: "🇮🇳" },
  { code: "fr", label: "Français",   flag: "🇫🇷" },
  { code: "ar", label: "العربية",    flag: "🇸🇦" },
  { code: "pt", label: "Português",  flag: "🇧🇷" },
  { code: "de", label: "Deutsch",    flag: "🇩🇪" },
  { code: "zh", label: "中文",        flag: "🇨🇳" },
];

// ─── Avatar config ────────────────────────────────────────────────────────────
// Using HSL-safe inline styles (avoids oklch in Chrome 108)
const AVATARS = [
  { id: "a1", gradient: "linear-gradient(135deg,hsl(262,83%,58%),hsl(272,72%,47%))", label: "A" },
  { id: "a2", gradient: "linear-gradient(135deg,hsl(188,78%,41%),hsl(221,83%,53%))", label: "B" },
  { id: "a3", gradient: "linear-gradient(135deg,hsl(351,83%,60%),hsl(330,81%,60%))", label: "C" },
  { id: "a4", gradient: "linear-gradient(135deg,hsl(38,92%,50%),hsl(21,90%,48%))",  label: "D" },
  { id: "a5", gradient: "linear-gradient(135deg,hsl(152,76%,40%),hsl(173,80%,40%))", label: "E" },
  { id: "a6", gradient: "linear-gradient(135deg,hsl(294,72%,60%),hsl(262,83%,58%))", label: "F" },
  { id: "a7", gradient: "linear-gradient(135deg,hsl(199,89%,48%),hsl(239,84%,67%))", label: "G" },
  { id: "a8", gradient: "linear-gradient(135deg,hsl(84,81%,44%),hsl(142,71%,38%))", label: "H" },
];

// ─── Quick prompts ────────────────────────────────────────────────────────────
const QUICK_PROMPTS = [
  { label: "Why are my sales dropping?",      icon: TrendingUp },
  { label: "How do I attract more customers?", icon: Users },
  { label: "Fix my marketing strategy",        icon: Target },
  { label: "How do I recover from losses?",    icon: DollarSign },
  { label: "Improve my branding",              icon: Zap },
  { label: "Build a pricing strategy",         icon: BarChart2 },
  { label: "Improve customer retention",       icon: Flame },
  { label: "Analyze my competitors",           icon: ShieldAlert },
];

const INDUSTRIES = [
  "Restaurant","Startup","E-commerce","Freelancing","Agency",
  "Salon","Gym","Retail Shop","Content Creator","SaaS",
  "Coaching","Real Estate","Local Business","Manufacturing","General",
];

// ─── Markdown renderer ────────────────────────────────────────────────────────
function renderMarkdown(text: string) {
  return text.split("\n").map((line, i) => {
    const parts = line.split(/(\*\*[^*]+\*\*)/g);
    const rendered = parts.map((p, j) =>
      p.startsWith("**") && p.endsWith("**")
        ? <strong key={j} className="font-semibold text-foreground">{p.replace(/\*\*/g, "")}</strong>
        : <span key={j}>{p}</span>
    );
    if (line.startsWith("- ") || line.startsWith("• "))
      return <div key={i} className="flex gap-2 mt-1"><span className="text-primary shrink-0">▸</span><p>{rendered}</p></div>;
    if (/^\d+\./.test(line))
      return <div key={i} className="flex gap-2 mt-1"><span className="text-primary shrink-0 font-bold">{line.match(/^\d+/)![0]}.</span><p>{rendered}</p></div>;
    if (line.trim() === "") return <div key={i} className="h-2" />;
    return <p key={i} className="mt-0.5 leading-relaxed">{rendered}</p>;
  });
}

// ─── User avatar ──────────────────────────────────────────────────────────────
function UserAvatar({ av }: { av: typeof AVATARS[0] }) {
  return (
    <div
      className="w-9 h-9 shrink-0 rounded-full flex items-center justify-center text-xs font-bold text-white shadow-lg mt-1"
      style={{ background: av.gradient }}
    >
      {av.label}
    </div>
  );
}

// ─── Language dropdown ────────────────────────────────────────────────────────
function LanguagePicker({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  const [open, setOpen] = useState(false);
  const current = LANGUAGES.find(l => l.code === value) ?? LANGUAGES[0];
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    const handle = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", handle);
    return () => document.removeEventListener("mousedown", handle);
  }, [open]);

  return (
    <div className="relative" ref={ref}>
      <button
        data-testid="button-language-picker"
        onClick={() => setOpen(o => !o)}
        className="flex items-center gap-1.5 px-2 py-1.5 rounded-lg border border-border/40 bg-card/60 hover:bg-card text-sm transition-all min-h-[40px]"
      >
        <Globe className="w-3.5 h-3.5 text-muted-foreground" />
        <span>{current.flag}</span>
        <span className="text-xs text-muted-foreground hidden sm:inline">{current.label}</span>
        <ChevronDown className="w-3 h-3 text-muted-foreground" />
      </button>
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -4, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -4, scale: 0.95 }}
            className="absolute right-0 top-full mt-1 z-50 bg-card border border-border/50 rounded-xl shadow-2xl overflow-hidden min-w-[160px]"
          >
            {LANGUAGES.map(lang => (
              <button
                key={lang.code}
                data-testid={`lang-option-${lang.code}`}
                onClick={() => { onChange(lang.code); setOpen(false); }}
                className={cn(
                  "w-full flex items-center gap-2.5 px-3 py-2.5 text-sm hover:bg-primary/10 transition-colors text-left min-h-[44px]",
                  value === lang.code && "bg-primary/10 text-primary"
                )}
              >
                <span className="text-base">{lang.flag}</span>
                <span>{lang.label}</span>
              </button>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

// ─── Avatar picker modal ──────────────────────────────────────────────────────
function AvatarPicker({ value, onChange, onClose }: {
  value: string; onChange: (v: string) => void; onClose: () => void;
}) {
  return (
    <motion.div
      initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.95, opacity: 0 }}
        onClick={e => e.stopPropagation()}
        className="bg-card border border-border/50 rounded-2xl p-6 shadow-2xl w-full max-w-xs"
      >
        <h3 className="font-bold text-base mb-4">Choose your avatar</h3>
        <div className="grid grid-cols-4 gap-3">
          {AVATARS.map(av => (
            <button
              key={av.id}
              data-testid={`avatar-${av.id}`}
              onClick={() => { onChange(av.id); onClose(); }}
              className={cn(
                "w-14 h-14 rounded-full flex items-center justify-center text-lg font-bold text-white transition-all ring-2 hover:scale-110 active:scale-95",
                value === av.id ? "ring-primary shadow-lg scale-110" : "ring-transparent"
              )}
              style={{ background: av.gradient }}
            >
              {av.label}
            </button>
          ))}
        </div>
        <Button variant="outline" className="w-full mt-4 min-h-[44px]" onClick={onClose}>Done</Button>
      </motion.div>
    </motion.div>
  );
}

// ─── Sessions sidebar ─────────────────────────────────────────────────────────
interface SessionsPanelProps {
  sessions: ReturnType<typeof useListChatSessions>["data"];
  loading: boolean;
  activeSessionId: number | null;
  onSelect: (id: number) => void;
  onDelete: (e: React.MouseEvent, id: number) => void;
  onNew: () => void;
  avatarId: string;
  onAvatarClick: () => void;
  /** mobile: whether panel is shown as overlay */
  mobileOpen: boolean;
  onMobileClose: () => void;
}
function SessionsPanel({
  sessions, loading, activeSessionId, onSelect, onDelete, onNew,
  avatarId, onAvatarClick, mobileOpen, onMobileClose,
}: SessionsPanelProps) {
  const av = AVATARS.find(a => a.id === avatarId) ?? AVATARS[0];

  const inner = (
    <div className="flex flex-col h-full">
      <div className="p-3 border-b border-border/30 shrink-0">
        <Button
          data-testid="button-new-chat"
          onClick={() => { onNew(); onMobileClose(); }}
          className="w-full bg-primary/20 text-primary border border-primary/40 hover:bg-primary/30 gap-2 min-h-[44px]"
        >
          <Plus className="w-4 h-4" /> New Chat
        </Button>
      </div>

      <div className="flex-1 overflow-y-auto">
        <div className="p-2 space-y-1">
          {loading && [1,2,3].map(i => (
            <div key={i} className="h-14 rounded-lg bg-muted/30 animate-pulse mx-1" />
          ))}
          {!loading && sessions?.length === 0 && (
            <p className="text-xs text-muted-foreground text-center py-8 px-4">
              No chats yet. Start one to get AI business guidance.
            </p>
          )}
          {sessions?.map(session => (
            <motion.div
              key={session.id}
              data-testid={`session-item-${session.id}`}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              onClick={() => { onSelect(session.id); onMobileClose(); }}
              className={cn(
                "group px-3 py-2.5 rounded-xl cursor-pointer transition-all border",
                activeSessionId === session.id
                  ? "bg-primary/10 border-primary/30 shadow-sm"
                  : "border-transparent hover:bg-card/60 hover:border-border/30"
              )}
            >
              <div className="flex items-start gap-2">
                <MessageSquare className={cn(
                  "w-4 h-4 mt-0.5 shrink-0",
                  activeSessionId === session.id ? "text-primary" : "text-muted-foreground"
                )} />
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-sm truncate">{session.title}</p>
                  <div className="flex items-center gap-1.5 mt-0.5">
                    <span className="text-xs text-muted-foreground truncate">{session.industry}</span>
                    {session.crisisMode && <AlertTriangle className="w-3 h-3 text-red-400 shrink-0" />}
                    <span className="text-xs text-muted-foreground ml-auto shrink-0">{session.messageCount}</span>
                  </div>
                </div>
                <button
                  data-testid={`button-delete-${session.id}`}
                  onClick={(e) => onDelete(e, session.id)}
                  className="opacity-0 group-hover:opacity-100 p-1.5 hover:text-red-400 text-muted-foreground rounded min-h-[36px] min-w-[36px] flex items-center justify-center"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      <div className="p-3 border-t border-border/30 shrink-0">
        <button
          data-testid="button-open-avatar-picker"
          onClick={onAvatarClick}
          className="flex items-center gap-2.5 w-full px-2 py-2 rounded-xl hover:bg-card/60 transition-colors min-h-[48px]"
        >
          <div
            className="w-9 h-9 shrink-0 rounded-full flex items-center justify-center text-sm font-bold text-white"
            style={{ background: av.gradient }}
          >
            {av.label}
          </div>
          <div className="text-left">
            <p className="text-xs font-medium">Your Avatar</p>
            <p className="text-xs text-muted-foreground">Tap to change</p>
          </div>
        </button>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop: always-visible */}
      <div className="hidden sm:flex w-64 shrink-0 flex-col bg-card/40 backdrop-blur-xl border-r border-border/30 h-full">
        {inner}
      </div>

      {/* Mobile: overlay drawer */}
      <AnimatePresence>
        {mobileOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              className="sm:hidden fixed inset-0 z-40 bg-black/60 backdrop-blur-sm"
              onClick={onMobileClose}
            />
            <motion.div
              initial={{ x: "-100%" }}
              animate={{ x: 0 }}
              exit={{ x: "-100%" }}
              transition={{ type: "spring", stiffness: 320, damping: 32 }}
              className="sm:hidden fixed inset-y-0 left-0 z-50 w-72 bg-card/95 backdrop-blur-xl border-r border-border/30 flex flex-col"
            >
              {inner}
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}

// ─── Main Chat page ───────────────────────────────────────────────────────────
export default function Chat() {
  const queryClient = useQueryClient();
  const { data: sessions, isLoading: loadingSessions } = useListChatSessions();
  const [activeSessionId, setActiveSessionId] = useState<number | null>(null);
  const [showNewModal, setShowNewModal] = useState(false);
  const [showAvatarPicker, setShowAvatarPicker] = useState(false);
  const [showMobileSessions, setShowMobileSessions] = useState(false);
  const [newTitle, setNewTitle] = useState("New Chat");
  const [newIndustry, setNewIndustry] = useState("General");
  const [crisisToggle, setCrisisToggle] = useState(false);

  const [language, setLanguage] = useState(() => localStorage.getItem("rvx-lang") ?? "en");
  const [avatarId, setAvatarId] = useState(() => localStorage.getItem("rvx-avatar") ?? "a1");
  const selectedAvatar = AVATARS.find(a => a.id === avatarId) ?? AVATARS[0];

  useEffect(() => { localStorage.setItem("rvx-lang", language); }, [language]);
  useEffect(() => { localStorage.setItem("rvx-avatar", avatarId); }, [avatarId]);

  // Voice
  const [isListening, setIsListening] = useState(false);
  const [voiceOut, setVoiceOut] = useState(false);
  const recognitionRef = useRef<SpeechRecognition | null>(null);
  const hasSpeech = typeof window !== "undefined" && ("SpeechRecognition" in window || "webkitSpeechRecognition" in window);

  const { data: activeSession, isLoading: loadingSession } = useGetChatSession(
    activeSessionId ?? 0,
    { query: { enabled: !!activeSessionId, queryKey: getGetChatSessionQueryKey(activeSessionId ?? 0) } }
  );

  const createSession = useCreateChatSession();
  const deleteSession = useDeleteChatSession();
  const sendMessage = useSendMessage();

  const [input, setInput] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (sessions && sessions.length > 0 && !activeSessionId) {
      setActiveSessionId(sessions[0].id);
    }
  }, [sessions, activeSessionId]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [activeSession?.messages, sendMessage.isPending]);

  const speak = useCallback((text: string) => {
    if (!voiceOut || !window.speechSynthesis) return;
    window.speechSynthesis.cancel();
    const utter = new SpeechSynthesisUtterance(text.replace(/\*\*/g, ""));
    const langMap: Record<string, string> = {
      en:"en-US", es:"es-ES", hi:"hi-IN", fr:"fr-FR", ar:"ar-SA", pt:"pt-BR", de:"de-DE", zh:"zh-CN",
    };
    utter.lang = langMap[language] ?? "en-US";
    utter.rate = 1.05;
    window.speechSynthesis.speak(utter);
  }, [voiceOut, language]);

  const toggleVoiceInput = () => {
    if (!hasSpeech) return;
    if (isListening) { recognitionRef.current?.stop(); setIsListening(false); return; }
    const SR = (window as unknown as { SpeechRecognition?: typeof SpeechRecognition; webkitSpeechRecognition?: typeof SpeechRecognition }).SpeechRecognition
      || (window as unknown as { webkitSpeechRecognition?: typeof SpeechRecognition }).webkitSpeechRecognition;
    if (!SR) return;
    const rec = new SR();
    const langMap: Record<string, string> = { en:"en-US", es:"es-ES", hi:"hi-IN", fr:"fr-FR", ar:"ar-SA", pt:"pt-BR", de:"de-DE", zh:"zh-CN" };
    rec.lang = langMap[language] ?? "en-US";
    rec.continuous = false;
    rec.interimResults = false;
    rec.onresult = (e) => { setInput(p => (p ? p + " " : "") + (e.results[0]?.[0]?.transcript ?? "")); setIsListening(false); };
    rec.onerror = () => setIsListening(false);
    rec.onend = () => setIsListening(false);
    rec.start();
    recognitionRef.current = rec;
    setIsListening(true);
  };

  const handleDelete = (e: React.MouseEvent, sessionId: number) => {
    e.stopPropagation();
    deleteSession.mutate({ sessionId }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListChatSessionsQueryKey() });
        if (activeSessionId === sessionId) setActiveSessionId(null);
      },
    });
  };

  const doSend = (content: string) => {
    if (!content.trim() || sendMessage.isPending) return;
    const doMutate = (sid: number) => {
      sendMessage.mutate({ sessionId: sid, data: { content, language } }, {
        onSuccess: (result) => {
          queryClient.invalidateQueries({ queryKey: getGetChatSessionQueryKey(sid) });
          queryClient.invalidateQueries({ queryKey: getListChatSessionsQueryKey() });
          speak(result.aiMessage.content);
        },
      });
    };
    setInput("");
    if (!activeSessionId) {
      createSession.mutate({ data: { title: content.slice(0, 45), industry: "General", crisisMode: false } }, {
        onSuccess: (s) => {
          queryClient.invalidateQueries({ queryKey: getListChatSessionsQueryKey() });
          setActiveSessionId(s.id);
          doMutate(s.id);
        },
      });
      return;
    }
    doMutate(activeSessionId);
  };

  const handleCreateSession = () => {
    createSession.mutate({ data: { title: newTitle || "New Chat", industry: newIndustry, crisisMode: crisisToggle } }, {
      onSuccess: (s) => {
        queryClient.invalidateQueries({ queryKey: getListChatSessionsQueryKey() });
        setActiveSessionId(s.id);
        setShowNewModal(false);
        setNewTitle("New Chat");
        setNewIndustry("General");
        setCrisisToggle(false);
      },
    });
  };

  const crisisMode = activeSession?.crisisMode ?? false;
  const messages = activeSession?.messages ?? [];
  const currentLang = LANGUAGES.find(l => l.code === language) ?? LANGUAGES[0];

  return (
    <AppLayout>
      {/* Full-height container — no padding override on mobile */}
      <div className="-mx-4 -mt-4 md:-mx-8 md:-mt-8 h-[calc(100vh-57px)] md:h-[calc(100vh-4rem)] flex overflow-hidden border-t border-border/20 md:rounded-xl md:border md:border-border/30">

        {/* Sessions panel */}
        <SessionsPanel
          sessions={sessions}
          loading={loadingSessions}
          activeSessionId={activeSessionId}
          onSelect={setActiveSessionId}
          onDelete={handleDelete}
          onNew={() => setShowNewModal(true)}
          avatarId={avatarId}
          onAvatarClick={() => setShowAvatarPicker(true)}
          mobileOpen={showMobileSessions}
          onMobileClose={() => setShowMobileSessions(false)}
        />

        {/* Main chat area */}
        <div className={cn(
          "flex-1 flex flex-col bg-background/60 backdrop-blur-xl relative overflow-hidden min-w-0",
          crisisMode && "bg-red-950/10"
        )}>
          {crisisMode && (
            <motion.div
              className="absolute inset-0 pointer-events-none z-0"
              animate={{ opacity: [0.03, 0.09, 0.03] }}
              transition={{ duration: 2, repeat: Infinity }}
              style={{ background: "radial-gradient(ellipse at center,rgba(239,68,68,0.18) 0%,transparent 70%)" }}
            />
          )}

          {/* Chat header */}
          <div className={cn(
            "px-3 sm:px-4 py-2.5 border-b border-border/30 flex items-center gap-2 sm:gap-3 relative z-10 shrink-0",
            crisisMode && "bg-red-500/5 border-red-500/20"
          )}>
            {/* Mobile sessions toggle */}
            <button
              data-testid="button-toggle-sessions"
              onClick={() => setShowMobileSessions(true)}
              className="sm:hidden p-2 rounded-lg border border-border/40 text-muted-foreground hover:text-foreground hover:border-primary/40 transition-all min-h-[40px] min-w-[40px] flex items-center justify-center"
              aria-label="Chat history"
            >
              <PanelLeftOpen className="w-4 h-4" />
            </button>

            <Orb className="w-9 h-9 sm:w-10 sm:h-10 shrink-0" pulsing={!sendMessage.isPending} thinking={sendMessage.isPending} crisisMode={crisisMode} />

            <div className="flex-1 min-w-0">
              <h2 className="font-bold text-sm leading-tight truncate">
                {activeSession?.title ?? "ReviveX AI"}
              </h2>
              <p className={cn("text-xs mt-0.5", sendMessage.isPending ? "text-primary animate-pulse" : "text-muted-foreground")}>
                {sendMessage.isPending ? "Thinking..." : activeSession ? `${activeSession.industry} · ${messages.length} msgs` : "Ready"}
              </p>
            </div>

            <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
              {crisisMode && (
                <div className="hidden sm:flex items-center gap-1 px-2 py-1 rounded-full bg-red-500/20 border border-red-500/30">
                  <AlertTriangle className="w-3 h-3 text-red-400" />
                  <span className="text-xs text-red-400 font-medium">Crisis</span>
                </div>
              )}
              <button
                data-testid="button-toggle-voice-out"
                onClick={() => { setVoiceOut(v => !v); window.speechSynthesis?.cancel(); }}
                className={cn(
                  "p-2 rounded-lg border transition-all min-h-[40px] min-w-[40px] flex items-center justify-center",
                  voiceOut ? "border-primary/50 text-primary bg-primary/10" : "border-border/30 text-muted-foreground hover:border-border"
                )}
              >
                {voiceOut ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
              </button>
              <LanguagePicker value={language} onChange={setLanguage} />
            </div>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-3 sm:p-5 relative z-10">
            <div className="max-w-3xl mx-auto space-y-4 sm:space-y-5">

              {/* Empty state */}
              {!activeSessionId && !loadingSession && (
                <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
                  className="flex flex-col items-center justify-center py-12 sm:py-16 text-center px-4"
                >
                  <Orb className="w-16 h-16 sm:w-20 sm:h-20 mx-auto mb-4 sm:mb-5" pulsing />
                  <h3 className="text-xl sm:text-2xl font-bold mb-2">Your AI Business Mentor</h3>
                  <p className="text-muted-foreground text-sm max-w-sm mb-2">
                    Chat in your language. Get expert business guidance.
                  </p>
                  <p className="text-xs text-muted-foreground mb-6">
                    {currentLang.flag} {currentLang.label} · change anytime above
                  </p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 w-full max-w-lg">
                    {QUICK_PROMPTS.slice(0, 4).map(({ label, icon: Icon }) => (
                      <button
                        key={label}
                        data-testid={`quick-prompt-${label}`}
                        onClick={() => doSend(label)}
                        className="flex items-center gap-2 p-3 rounded-xl border border-border/40 bg-card/40 hover:bg-card hover:border-primary/40 text-left text-sm transition-all group min-h-[48px]"
                      >
                        <Icon className="w-4 h-4 text-primary shrink-0" />
                        <span className="text-muted-foreground group-hover:text-foreground text-xs">{label}</span>
                      </button>
                    ))}
                  </div>
                </motion.div>
              )}

              {/* Welcome message */}
              {activeSessionId && messages.length === 0 && !loadingSession && !sendMessage.isPending && (
                <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="flex gap-3">
                  <Orb className="w-9 h-9 shrink-0 mt-1" />
                  <div className="px-4 py-3.5 rounded-2xl rounded-tl-sm bg-card/60 border border-border/40 max-w-[85%]">
                    <p className="text-sm leading-relaxed text-muted-foreground">Hello — I'm your ReviveX AI strategist.</p>
                    <p className="text-sm leading-relaxed mt-1.5">
                      You can chat with me in <strong className="text-foreground">{currentLang.flag} {currentLang.label}</strong>. What's your biggest business challenge right now?
                    </p>
                  </div>
                </motion.div>
              )}

              {/* Messages */}
              <AnimatePresence initial={false}>
                {messages.map((msg) => (
                  <motion.div
                    key={msg.id}
                    data-testid={`message-${msg.id}`}
                    initial={{ opacity: 0, y: 12 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.25 }}
                    className={cn("flex gap-3", msg.role === "user" ? "flex-row-reverse" : "")}
                  >
                    {msg.role === "ai" ? <Orb className="w-8 h-8 sm:w-9 sm:h-9 shrink-0 mt-1" /> : <UserAvatar av={selectedAvatar} />}
                    <div className={cn(
                      "px-3 sm:px-4 py-3 rounded-2xl max-w-[85%] sm:max-w-[82%] text-sm",
                      msg.role === "user"
                        ? "bg-primary text-primary-foreground rounded-tr-sm"
                        : "bg-card/60 border border-border/40 rounded-tl-sm"
                    )}>
                      {msg.role === "ai"
                        ? <div className="leading-relaxed space-y-0.5">{renderMarkdown(msg.content)}</div>
                        : <p className="leading-relaxed">{msg.content}</p>
                      }
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>

              {/* Typing indicator */}
              {sendMessage.isPending && (
                <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="flex gap-3">
                  <Orb className="w-8 h-8 sm:w-9 sm:h-9 shrink-0 mt-1" thinking />
                  <div className="px-4 py-4 rounded-2xl rounded-tl-sm bg-card/60 border border-border/40 flex items-center gap-1.5">
                    {[0, 0.15, 0.3].map((delay, i) => (
                      <motion.div key={i} className="w-2 h-2 bg-primary rounded-full"
                        animate={{ y: [0, -6, 0] }} transition={{ duration: 0.7, repeat: Infinity, delay }} />
                    ))}
                  </div>
                </motion.div>
              )}

              <div ref={messagesEndRef} />
            </div>
          </div>

          {/* Input area */}
          <div className="relative z-10 border-t border-border/30 bg-background/50 backdrop-blur-xl px-3 sm:px-4 pt-2.5 pb-3 sm:pb-4 shrink-0">
            <div className="max-w-3xl mx-auto">
              {/* Quick prompts */}
              <div className="flex gap-2 mb-2.5 overflow-x-auto pb-1 scrollbar-none">
                {QUICK_PROMPTS.map(({ label, icon: Icon }) => (
                  <button
                    key={label}
                    data-testid={`chip-${label}`}
                    onClick={() => doSend(label)}
                    disabled={sendMessage.isPending}
                    className="flex items-center gap-1.5 text-xs px-3 py-2 rounded-full border border-border/40 bg-card/40 hover:bg-card hover:border-primary/40 hover:text-primary whitespace-nowrap transition-all shrink-0 text-muted-foreground disabled:opacity-40 min-h-[36px]"
                  >
                    <Icon className="w-3 h-3" />
                    <span className="hidden sm:inline">{label}</span>
                    <span className="sm:hidden">{label.split(" ").slice(0, 3).join(" ")}</span>
                  </button>
                ))}
              </div>

              {/* Input row */}
              <div className="flex gap-2">
                {hasSpeech && (
                  <button
                    data-testid="button-voice-input"
                    onClick={toggleVoiceInput}
                    className={cn(
                      "h-12 w-12 rounded-xl border flex items-center justify-center shrink-0 transition-all",
                      isListening
                        ? "bg-red-500/20 border-red-500/50 text-red-400 animate-pulse"
                        : "border-border/40 bg-card/50 text-muted-foreground hover:border-primary/40 hover:text-primary"
                    )}
                  >
                    {isListening ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
                  </button>
                )}
                <Input
                  data-testid="input-message"
                  value={input}
                  onChange={e => setInput(e.target.value)}
                  onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); doSend(input); } }}
                  placeholder={isListening ? "Listening..." : `Message in ${currentLang.flag} ${currentLang.label}...`}
                  className="h-12 bg-card/50 border-border/40 focus:border-primary/60 flex-1 text-base"
                  style={{ fontSize: "16px" }} /* prevents iOS auto-zoom */
                  disabled={sendMessage.isPending || createSession.isPending || isListening}
                  dir={language === "ar" ? "rtl" : "ltr"}
                />
                <Button
                  data-testid="button-send"
                  onClick={() => doSend(input)}
                  size="icon"
                  className="h-12 w-12 bg-primary hover:bg-primary/80 text-primary-foreground shrink-0"
                  disabled={sendMessage.isPending || createSession.isPending || !input.trim()}
                >
                  <Send className="w-5 h-5" />
                </Button>
              </div>

              <p className="text-xs text-muted-foreground text-center mt-2 hidden sm:block">
                8 languages · Voice input · AI-powered business strategy
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* New Chat Modal */}
      <AnimatePresence>
        {showNewModal && (
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-sm p-0 sm:p-4"
            onClick={() => setShowNewModal(false)}
          >
            <motion.div
              initial={{ y: "100%", opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: "100%", opacity: 0 }}
              transition={{ type: "spring", stiffness: 300, damping: 30 }}
              onClick={e => e.stopPropagation()}
              className="w-full sm:max-w-md bg-card border border-border/50 rounded-t-2xl sm:rounded-2xl p-5 shadow-2xl max-h-[90vh] overflow-y-auto"
            >
              <h3 className="text-lg font-bold mb-4">Start a New Chat</h3>
              <div className="space-y-4">
                <div>
                  <label className="text-sm text-muted-foreground mb-1.5 block">Chat Title</label>
                  <Input
                    data-testid="input-session-title"
                    value={newTitle}
                    onChange={e => setNewTitle(e.target.value)}
                    placeholder="e.g. Revenue Recovery Plan"
                    className="bg-background border-border/40"
                    style={{ fontSize: "16px" }}
                  />
                </div>
                <div>
                  <label className="text-sm text-muted-foreground mb-1.5 block">Your Industry</label>
                  <div className="grid grid-cols-3 gap-1.5">
                    {INDUSTRIES.map(ind => (
                      <button
                        key={ind}
                        data-testid={`industry-${ind}`}
                        onClick={() => setNewIndustry(ind)}
                        className={cn(
                          "text-xs py-2.5 px-2 rounded-lg border transition-all min-h-[40px]",
                          newIndustry === ind
                            ? "bg-primary/20 border-primary/50 text-primary"
                            : "border-border/30 bg-background/50 text-muted-foreground hover:border-border"
                        )}
                      >
                        {ind}
                      </button>
                    ))}
                  </div>
                </div>
                <div className="flex items-center justify-between p-3 rounded-xl border border-red-500/20 bg-red-500/5">
                  <div>
                    <p className="text-sm font-medium text-red-400">Crisis Mode</p>
                    <p className="text-xs text-muted-foreground">For businesses in severe distress</p>
                  </div>
                  <button
                    data-testid="toggle-crisis-mode"
                    onClick={() => setCrisisToggle(v => !v)}
                    className={cn("w-11 h-6 rounded-full transition-colors relative shrink-0", crisisToggle ? "bg-red-500" : "bg-muted")}
                  >
                    <span className={cn(
                      "absolute top-0.5 w-5 h-5 rounded-full bg-white transition-transform shadow",
                      crisisToggle ? "translate-x-5" : "translate-x-0.5"
                    )} />
                  </button>
                </div>
                <div className="flex gap-3 pt-1">
                  <Button variant="outline" className="flex-1 min-h-[48px]" onClick={() => setShowNewModal(false)}>Cancel</Button>
                  <Button
                    data-testid="button-create-session"
                    className="flex-1 bg-primary text-primary-foreground min-h-[48px]"
                    onClick={handleCreateSession}
                    disabled={createSession.isPending}
                  >
                    {createSession.isPending ? "Starting..." : "Start Chat"}
                  </Button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Avatar Picker */}
      <AnimatePresence>
        {showAvatarPicker && (
          <AvatarPicker value={avatarId} onChange={setAvatarId} onClose={() => setShowAvatarPicker(false)} />
        )}
      </AnimatePresence>
    </AppLayout>
  );
}
