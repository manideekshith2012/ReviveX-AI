import { useGetDashboardSummary, useGetRecoveryMetrics, useGetMotivationalQuote } from "@workspace/api-client-react";
import { AppLayout } from "@/components/layout/AppLayout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { LineChart, Line, XAxis, YAxis, Tooltip as RechartsTooltip, ResponsiveContainer, RadialBarChart, RadialBar, PolarAngleAxis } from "recharts";
import { Activity, Flame, ShieldAlert, Target, TrendingUp, Zap } from "lucide-react";
import { motion } from "framer-motion";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";

export default function Dashboard() {
  const { data: summary, isLoading: loadingSummary } = useGetDashboardSummary();
  const { data: metrics, isLoading: loadingMetrics } = useGetRecoveryMetrics();
  const { data: quote, isLoading: loadingQuote } = useGetMotivationalQuote();

  return (
    <AppLayout>
      <div className="space-y-8">
        <header>
          <h1 className="text-3xl font-bold tracking-tight">Command Center</h1>
          <p className="text-muted-foreground mt-1">Live metrics and system status.</p>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card className="md:col-span-1 bg-card/50 backdrop-blur border-border/50 shadow-lg relative overflow-hidden group">
            <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <Activity className="w-4 h-4 text-primary" /> System Health
              </CardTitle>
            </CardHeader>
            <CardContent>
              {loadingSummary ? <Skeleton className="h-32 w-32 rounded-full mx-auto" /> : (
                <div className="h-32 relative flex items-center justify-center">
                   <ResponsiveContainer width="100%" height="100%">
                    <RadialBarChart 
                      cx="50%" cy="50%" innerRadius="80%" outerRadius="100%" 
                      barSize={10} data={[{ name: 'Health', value: summary?.healthScore || 0, fill: 'hsl(var(--primary))' }]}
                      startAngle={180} endAngle={0}
                    >
                      <PolarAngleAxis type="number" domain={[0, 100]} angleAxisId={0} tick={false} />
                      <RadialBar background={{ fill: 'hsl(var(--muted))' }} dataKey="value" cornerRadius={10} />
                    </RadialBarChart>
                  </ResponsiveContainer>
                  <div className="absolute inset-0 flex flex-col items-center justify-center -mt-4">
                    <span className="text-3xl font-bold text-foreground">{summary?.healthScore}</span>
                    <span className="text-xs text-muted-foreground">SCORE</span>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="md:col-span-1 bg-card/50 backdrop-blur border-border/50 shadow-lg relative overflow-hidden group">
             <div className="absolute inset-0 bg-gradient-to-br from-orange-500/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <Flame className="w-4 h-4 text-orange-500" /> Recovery Streak
              </CardTitle>
            </CardHeader>
            <CardContent>
               {loadingSummary ? <Skeleton className="h-12 w-24" /> : (
                 <div className="flex items-end gap-2">
                   <span className="text-4xl font-bold text-foreground">{summary?.recoveryStreak}</span>
                   <span className="text-sm text-muted-foreground mb-1">DAYS</span>
                 </div>
               )}
            </CardContent>
          </Card>

           <Card className="md:col-span-2 bg-card/50 backdrop-blur border-border/50 shadow-lg relative overflow-hidden">
             <div className="absolute inset-0 bg-gradient-to-r from-primary/5 to-transparent" />
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <Zap className="w-4 h-4 text-primary" /> Directive
              </CardTitle>
            </CardHeader>
            <CardContent>
               {loadingQuote ? <Skeleton className="h-16 w-full" /> : (
                 <blockquote className="space-y-2">
                   <p className="text-lg italic text-foreground/90">"{quote?.quote}"</p>
                   <footer className="text-sm text-muted-foreground">— {quote?.author}</footer>
                 </blockquote>
               )}
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="md:col-span-2 bg-card/50 backdrop-blur border-border/50 shadow-lg">
            <CardHeader>
              <CardTitle className="text-lg font-medium flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-primary" /> Recovery Trajectory
              </CardTitle>
            </CardHeader>
            <CardContent>
              {loadingMetrics ? <Skeleton className="h-64 w-full" /> : (
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={metrics?.weekly}>
                      <XAxis dataKey="week" stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} />
                      <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} tickLine={false} axisLine={false} />
                      <RechartsTooltip 
                        contentStyle={{ backgroundColor: 'hsl(var(--card))', borderColor: 'hsl(var(--border))', borderRadius: '8px' }}
                        itemStyle={{ color: 'hsl(var(--foreground))' }}
                      />
                      <Line type="monotone" dataKey="healthScore" stroke="hsl(var(--primary))" strokeWidth={2} dot={{ fill: 'hsl(var(--primary))', strokeWidth: 2 }} activeDot={{ r: 6 }} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              )}
            </CardContent>
          </Card>

          <div className="space-y-4">
             <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wider mb-4">Quick Directives</h3>
             
             <Link href="/chat">
                <Button className="w-full justify-start h-14 bg-card hover:bg-card/80 border border-border/50 hover:border-primary/50 text-foreground group transition-all">
                  <div className="w-8 h-8 rounded bg-primary/10 flex items-center justify-center mr-3 group-hover:scale-110 transition-transform">
                    <Activity className="w-4 h-4 text-primary" />
                  </div>
                  New AI Consultation
                </Button>
             </Link>
             
             <Link href="/diagnosis">
                <Button className="w-full justify-start h-14 bg-card hover:bg-card/80 border border-border/50 hover:border-primary/50 text-foreground group transition-all">
                  <div className="w-8 h-8 rounded bg-destructive/10 flex items-center justify-center mr-3 group-hover:scale-110 transition-transform">
                    <ShieldAlert className="w-4 h-4 text-destructive" />
                  </div>
                  Run Deep Diagnosis
                </Button>
             </Link>

              <Link href="/action-plan">
                <Button className="w-full justify-start h-14 bg-card hover:bg-card/80 border border-border/50 hover:border-primary/50 text-foreground group transition-all">
                  <div className="w-8 h-8 rounded bg-green-500/10 flex items-center justify-center mr-3 group-hover:scale-110 transition-transform">
                    <Target className="w-4 h-4 text-green-500" />
                  </div>
                  Generate Action Plan
                </Button>
             </Link>
          </div>
        </div>

      </div>
    </AppLayout>
  );
}
